To run this program, import it to your Java IDE
Go to the ChessClient class and set whether you 
need to go a AI vs AI or man vs AI, in method
start.
Have fun!